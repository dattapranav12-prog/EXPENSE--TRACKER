import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  CATEGORIES,
  calculateCategoryTotals,
  calculateTotal,
  filterByMonth,
  formatDate,
  formatMoney,
  highestCategory,
  loadBudget,
  loadExpenses,
  saveBudget,
  saveExpenses,
  toCSV,
  type Category,
  type Expense,
} from "@/lib/expenses";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Expense Tracker — Log daily spending by category" },
      {
        name: "description",
        content:
          "A simple expense tracker: add daily expenses with category, description and amount, then see your total, monthly summary, budget and category-wise spending.",
      },
      { property: "og:title", content: "Expense Tracker — Log daily spending by category" },
      {
        property: "og:description",
        content:
          "Add daily expenses across Food, Travel, Shopping, Education and Other, and see totals, budget and category-wise spending instantly.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ExpenseTrackerPage,
});

const categoryColor: Record<Category, string> = {
  Food: "bg-cat-food",
  Travel: "bg-cat-travel",
  Shopping: "bg-cat-shopping",
  Education: "bg-cat-education",
  Other: "bg-cat-other",
};

const categoryVar: Record<Category, string> = {
  Food: "var(--cat-food)",
  Travel: "var(--cat-travel)",
  Shopping: "var(--cat-shopping)",
  Education: "var(--cat-education)",
  Other: "var(--cat-other)",
};

const categoryTint: Record<Category, string> = {
  Food: "bg-cat-food/12 text-cat-food",
  Travel: "bg-cat-travel/12 text-cat-travel",
  Shopping: "bg-cat-shopping/12 text-cat-shopping",
  Education: "bg-cat-education/12 text-cat-education",
  Other: "bg-cat-other/12 text-cat-other",
};

function todayISO() {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${now.getFullYear()}-${month}-${day}`;
}

function currentMonth() {
  return todayISO().slice(0, 7);
}

function ExpenseTrackerPage() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loaded, setLoaded] = useState(false);

  // form
  const [category, setCategory] = useState<Category>("Food");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState("");
  const [error, setError] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);

  // search + filters
  const [search, setSearch] = useState("");
  const [filterCategory, setFilterCategory] = useState<"All" | Category>("All");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  // budget
  const [budget, setBudget] = useState(0);
  const [budgetInput, setBudgetInput] = useState("");

  useEffect(() => {
    setExpenses(loadExpenses());
    setBudget(loadBudget());
    setDate(todayISO());
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (loaded) saveExpenses(expenses);
  }, [expenses, loaded]);

  const total = useMemo(() => calculateTotal(expenses), [expenses]);
  const categoryTotals = useMemo(() => calculateCategoryTotals(expenses), [expenses]);

  const monthExpenses = useMemo(() => filterByMonth(expenses, currentMonth()), [expenses]);
  const monthTotal = useMemo(() => calculateTotal(monthExpenses), [monthExpenses]);
  const monthTop = useMemo(() => highestCategory(monthExpenses), [monthExpenses]);

  // Search + filter: keep only the expenses that match every rule.
  const visibleExpenses = useMemo(() => {
    const text = search.trim().toLowerCase();
    return expenses.filter((expense) => {
      const matchesText =
        text === "" ||
        expense.description.toLowerCase().includes(text) ||
        expense.category.toLowerCase().includes(text);
      const matchesCategory = filterCategory === "All" || expense.category === filterCategory;
      const matchesFrom = fromDate === "" || expense.date >= fromDate;
      const matchesTo = toDate === "" || expense.date <= toDate;
      return matchesText && matchesCategory && matchesFrom && matchesTo;
    });
  }, [expenses, search, filterCategory, fromDate, toDate]);

  function resetForm() {
    setEditingId(null);
    setDescription("");
    setAmount("");
    setCategory("Food");
    setDate(todayISO());
    setError("");
  }

  function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    const value = Number(amount);

    if (description.trim() === "") {
      setError("Please write a short description.");
      return;
    }
    if (!Number.isFinite(value) || value <= 0) {
      setError("Please enter an amount greater than zero.");
      return;
    }

    if (editingId) {
      setExpenses(
        expenses.map((expense) =>
          expense.id === editingId
            ? {
                ...expense,
                category,
                description: description.trim(),
                amount: value,
                date: date || todayISO(),
              }
            : expense,
        ),
      );
      resetForm();
      return;
    }

    const newExpense: Expense = {
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      category,
      description: description.trim(),
      amount: value,
      date: date || todayISO(),
    };

    setExpenses([newExpense, ...expenses]);
    resetForm();
  }

  function handleEdit(expense: Expense) {
    setEditingId(expense.id);
    setCategory(expense.category);
    setDescription(expense.description);
    setAmount(String(expense.amount));
    setDate(expense.date);
    setError("");
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handleDelete(expense: Expense) {
    const ok = window.confirm(
      `Delete "${expense.description}" (${formatMoney(expense.amount)})? This cannot be undone.`,
    );
    if (!ok) return;
    setExpenses(expenses.filter((item) => item.id !== expense.id));
    if (editingId === expense.id) resetForm();
  }

  function handleSaveBudget(event: React.FormEvent) {
    event.preventDefault();
    const value = Number(budgetInput);
    if (!Number.isFinite(value) || value < 0) return;
    setBudget(value);
    saveBudget(value);
    setBudgetInput("");
  }

  function handleExportCSV() {
    const csv = toCSV(visibleExpenses.length > 0 ? visibleExpenses : expenses);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "expenses.csv";
    link.click();
    URL.revokeObjectURL(url);
  }

  const budgetSpent = monthTotal;
  const budgetPercent = budget > 0 ? Math.min(Math.round((budgetSpent / budget) * 100), 100) : 0;
  const budgetRemaining = budget - budgetSpent;

  // Donut chart maths: each slice is a piece of the circle.
  const circumference = 2 * Math.PI * 52;
  let dashOffset = 0;

  const fieldClass =
    "mt-1.5 w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm text-foreground outline-none transition-shadow placeholder:text-muted-foreground/70 focus:ring-2 focus:ring-ring";
  const labelClass = "text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground";

  return (
    <div className="min-h-screen">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-5 py-5 sm:px-8">
          <div className="flex items-center gap-3">
            <div className="grid size-9 place-items-center rounded-xl bg-primary text-primary-foreground">
              <span className="text-lg font-bold">₹</span>
            </div>
            <div>
              <p className="text-base font-bold leading-none text-ink">Expense Tracker</p>
              <p className="mt-1 text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
                daily spending log
              </p>
            </div>
          </div>
          <p className="hand hidden text-xl text-primary sm:block">know where it goes</p>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-5 py-8 sm:px-8">
        <section className="rise-in">
          <p className="hand text-2xl text-primary">A small habit, a clear picture</p>
          <h1 className="mt-1 max-w-[18ch] text-4xl font-extrabold leading-[1.05] text-ink sm:text-5xl">
            Track every rupee you spend.
          </h1>
          <p className="mt-3 max-w-[52ch] text-sm text-muted-foreground">
            Add an expense with its category, description and amount. Your total and category-wise
            spending update straight away.
          </p>
        </section>

        <div className="mt-8 grid grid-cols-1 gap-5 lg:grid-cols-12">
          <form onSubmit={handleSubmit} className="paper rise-in p-5 lg:col-span-5">
            <div className="flex items-baseline justify-between gap-3">
              <h2 className="text-lg font-bold text-ink">
                {editingId ? "Edit expense" : "Add an expense"}
              </h2>
              {editingId ? (
                <button
                  type="button"
                  onClick={resetForm}
                  className="text-xs font-semibold text-muted-foreground underline underline-offset-4"
                >
                  Cancel
                </button>
              ) : null}
            </div>

            <label className="mt-4 block">
              <span className={labelClass}>Category</span>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Category)}
                className={fieldClass}
              >
                {CATEGORIES.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </label>

            <label className="mt-3 block">
              <span className={labelClass}>Description</span>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="e.g. Lunch at canteen"
                className={fieldClass}
              />
            </label>

            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <label className="block">
                <span className={labelClass}>Amount</span>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className={fieldClass}
                />
              </label>
              <label className="block">
                <span className={labelClass}>Date</span>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className={fieldClass}
                />
              </label>
            </div>

            {error ? <p className="mt-3 text-sm text-destructive">{error}</p> : null}

            <button
              type="submit"
              className="mt-5 w-full rounded-xl bg-primary py-2.5 text-sm font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5"
            >
              {editingId ? "Save changes" : "Add expense"}
            </button>
          </form>

          <div className="flex flex-col gap-5 lg:col-span-7">
            <div className="grid grid-cols-2 gap-5">
              <div className="paper rise-in p-5">
                <p className={labelClass}>Total spent</p>
                <p className="mt-2 text-3xl font-extrabold leading-none text-ink sm:text-4xl">
                  {formatMoney(total)}
                </p>
              </div>
              <div className="paper rise-in p-5">
                <p className={labelClass}>Entries</p>
                <p className="mt-2 text-3xl font-extrabold leading-none text-ink sm:text-4xl">
                  {expenses.length}
                </p>
              </div>
            </div>

            <div className="paper rise-in p-5">
              <div className="flex items-baseline justify-between">
                <h2 className="text-lg font-bold text-ink">By category</h2>
                <span className="text-xs text-muted-foreground">Share of total</span>
              </div>

              <div className="mt-4 flex flex-col items-center gap-6 sm:flex-row sm:items-center">
                <div className="relative shrink-0">
                  <svg width="132" height="132" viewBox="0 0 132 132" role="img" aria-label="Category spending chart">
                    <circle cx="66" cy="66" r="52" fill="none" stroke="var(--muted)" strokeWidth="16" />
                    {total > 0
                      ? CATEGORIES.map((item) => {
                          const value = categoryTotals[item];
                          if (value <= 0) return null;
                          const length = (value / total) * circumference;
                          const offset = dashOffset;
                          dashOffset = dashOffset + length;
                          return (
                            <circle
                              key={item}
                              cx="66"
                              cy="66"
                              r="52"
                              fill="none"
                              stroke={categoryVar[item]}
                              strokeWidth="16"
                              strokeDasharray={`${length} ${circumference - length}`}
                              strokeDashoffset={-offset}
                              transform="rotate(-90 66 66)"
                            />
                          );
                        })
                      : null}
                  </svg>
                  <div className="pointer-events-none absolute inset-0 grid place-items-center text-center">
                    <div>
                      <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Total</p>
                      <p className="text-sm font-bold text-ink">{formatMoney(total)}</p>
                    </div>
                  </div>
                </div>

                <div className="w-full space-y-3.5">
                  {CATEGORIES.map((item) => {
                    const value = categoryTotals[item];
                    const percent = total > 0 ? Math.round((value / total) * 100) : 0;
                    return (
                      <div key={item}>
                        <div className="flex items-center justify-between text-sm">
                          <span className="font-medium text-ink">{item}</span>
                          <span className="text-muted-foreground">
                            {formatMoney(value)} · {percent}%
                          </span>
                        </div>
                        <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-muted">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${categoryColor[item]}`}
                            style={{ width: `${percent}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-1 gap-5 lg:grid-cols-2">
          <section className="paper rise-in p-5">
            <h2 className="text-lg font-bold text-ink">This month</h2>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div>
                <p className={labelClass}>Spent</p>
                <p className="mt-1.5 text-2xl font-extrabold text-ink">{formatMoney(monthTotal)}</p>
              </div>
              <div>
                <p className={labelClass}>Expenses</p>
                <p className="mt-1.5 text-2xl font-extrabold text-ink">{monthExpenses.length}</p>
              </div>
            </div>
            <p className="mt-4 text-sm text-muted-foreground">
              Highest category:{" "}
              <span className="font-semibold text-ink">
                {monthTop ? `${monthTop.category} · ${formatMoney(monthTop.amount)}` : "—"}
              </span>
            </p>
          </section>

          <section className="paper rise-in p-5">
            <h2 className="text-lg font-bold text-ink">Monthly budget</h2>
            <form onSubmit={handleSaveBudget} className="mt-3 flex flex-col gap-2 sm:flex-row">
              <input
                type="number"
                min="0"
                step="1"
                value={budgetInput}
                onChange={(e) => setBudgetInput(e.target.value)}
                placeholder={budget > 0 ? String(budget) : "e.g. 5000"}
                className="w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring"
              />
              <button
                type="submit"
                className="rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground"
              >
                Set
              </button>
            </form>

            {budget > 0 ? (
              <div className="mt-4">
                <div className="flex flex-wrap items-baseline justify-between gap-2 text-sm">
                  <span className="text-muted-foreground">
                    Spent <span className="font-semibold text-ink">{formatMoney(budgetSpent)}</span> of{" "}
                    {formatMoney(budget)}
                  </span>
                  <span
                    className={
                      budgetRemaining < 0 ? "font-semibold text-destructive" : "font-semibold text-ink"
                    }
                  >
                    {budgetRemaining >= 0
                      ? `${formatMoney(budgetRemaining)} left`
                      : `${formatMoney(Math.abs(budgetRemaining))} over`}
                  </span>
                </div>
                <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-muted">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      budgetSpent > budget
                        ? "bg-destructive"
                        : budgetSpent >= budget * 0.8
                          ? "bg-cat-shopping"
                          : "bg-primary"
                    }`}
                    style={{ width: `${budgetPercent}%` }}
                  />
                </div>
                {budgetSpent > budget ? (
                  <p className="mt-2 text-sm font-semibold text-destructive">
                    You have crossed your monthly budget.
                  </p>
                ) : budgetSpent >= budget * 0.8 ? (
                  <p className="mt-2 text-sm font-semibold text-primary">
                    Careful — you have used {budgetPercent}% of your budget.
                  </p>
                ) : null}
              </div>
            ) : (
              <p className="mt-4 text-sm text-muted-foreground">
                Set a monthly budget to see how much is left.
              </p>
            )}
          </section>
        </div>

        <section className="paper rise-in mt-5 p-5">
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <h2 className="text-lg font-bold text-ink">All expenses</h2>
            <div className="flex items-center gap-3">
              <span className="text-xs text-muted-foreground">Newest first</span>
              <button
                type="button"
                onClick={handleExportCSV}
                className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-ink transition-colors hover:border-primary hover:text-primary"
              >
                Export CSV
              </button>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <label className="block sm:col-span-2 lg:col-span-1">
              <span className={labelClass}>Search</span>
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Description or category"
                className={fieldClass}
              />
            </label>
            <label className="block">
              <span className={labelClass}>Category</span>
              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value as "All" | Category)}
                className={fieldClass}
              >
                <option value="All">All</option>
                {CATEGORIES.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className={labelClass}>From</span>
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className={fieldClass}
              />
            </label>
            <label className="block">
              <span className={labelClass}>To</span>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className={fieldClass}
              />
            </label>
          </div>

          {expenses.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">
              No expenses yet. Add your first one using the form above.
            </p>
          ) : visibleExpenses.length === 0 ? (
            <div className="py-10 text-center">
              <p className="text-sm text-muted-foreground">
                No expenses match your search or filters.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSearch("");
                  setFilterCategory("All");
                  setFromDate("");
                  setToDate("");
                }}
                className="mt-3 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-ink hover:border-primary hover:text-primary"
              >
                Clear search and filters
              </button>
            </div>
          ) : (
            <ul className="mt-3 divide-y divide-border">
              {visibleExpenses.map((expense) => (
                <li
                  key={expense.id}
                  className="rise-in flex flex-wrap items-center gap-3 py-3 sm:flex-nowrap"
                >
                  <span
                    className={`grid size-9 shrink-0 place-items-center rounded-xl text-xs font-bold ${categoryTint[expense.category]}`}
                  >
                    {expense.category.slice(0, 2).toUpperCase()}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-ink">{expense.description}</p>
                    <p className="text-xs text-muted-foreground">
                      {expense.category} · {formatDate(expense.date)}
                    </p>
                  </div>
                  <span className="text-sm font-semibold text-ink">
                    {formatMoney(expense.amount)}
                  </span>
                  <div className="flex shrink-0 gap-2">
                    <button
                      type="button"
                      onClick={() => handleEdit(expense)}
                      className="rounded-lg border border-border px-2 py-1 text-xs text-muted-foreground transition-colors hover:border-primary/50 hover:text-primary"
                    >
                      Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(expense)}
                      className="rounded-lg border border-border px-2 py-1 text-xs text-muted-foreground transition-colors hover:border-destructive/40 hover:text-destructive"
                    >
                      Delete
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>

      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-5 text-[10px] uppercase tracking-[0.24em] text-muted-foreground sm:px-8">
          <span>Expense Tracker</span>
          <span>College project</span>
        </div>
      </footer>
    </div>
  );
}
