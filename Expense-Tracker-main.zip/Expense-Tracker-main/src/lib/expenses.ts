// Simple, beginner-friendly expense logic.
// Kept as plain functions so it is easy to read and explain.

export const CATEGORIES = ["Food", "Travel", "Shopping", "Education", "Other"] as const;

export type Category = (typeof CATEGORIES)[number];

export type Expense = {
  id: string;
  category: Category;
  description: string;
  amount: number;
  date: string; // YYYY-MM-DD
};

// Total = add up the amount of every expense.
export function calculateTotal(expenses: Expense[]): number {
  let total = 0;
  for (const expense of expenses) {
    total = total + expense.amount;
  }
  return total;
}

// Category-wise = start every category at 0, then add each expense
// to the bucket that matches its category.
export function calculateCategoryTotals(expenses: Expense[]): Record<Category, number> {
  const totals = {} as Record<Category, number>;
  for (const category of CATEGORIES) {
    totals[category] = 0;
  }
  for (const expense of expenses) {
    totals[expense.category] = (totals[expense.category] ?? 0) + expense.amount;
  }
  return totals;
}

// Keep only the expenses that belong to the given month ("YYYY-MM").
export function filterByMonth(expenses: Expense[], month: string): Expense[] {
  return expenses.filter((expense) => expense.date.slice(0, 7) === month);
}

// The category with the biggest total (or null when there is nothing).
export function highestCategory(expenses: Expense[]): { category: Category; amount: number } | null {
  const totals = calculateCategoryTotals(expenses);
  let best: { category: Category; amount: number } | null = null;
  for (const category of CATEGORIES) {
    const amount = totals[category];
    if (amount > 0 && (best === null || amount > best.amount)) {
      best = { category, amount };
    }
  }
  return best;
}

export function formatMoney(amount: number): string {
  return "₹" + amount.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function formatDate(date: string): string {
  const parsed = new Date(date + "T00:00:00");
  if (Number.isNaN(parsed.getTime())) return date;
  return parsed.toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}

// Build a CSV text: one header row, then one row per expense.
export function toCSV(expenses: Expense[]): string {
  const rows = [["Date", "Category", "Description", "Amount"]];
  for (const expense of expenses) {
    rows.push([expense.date, expense.category, expense.description, String(expense.amount)]);
  }
  return rows
    .map((row) => row.map((cell) => `"${cell.replace(/"/g, '""')}"`).join(","))
    .join("\n");
}

const STORAGE_KEY = "expense-tracker-entries";
const BUDGET_KEY = "expense-tracker-budget";

export function loadExpenses(): Expense[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Expense[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveExpenses(expenses: Expense[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(expenses));
  } catch {
    // ignore storage errors (private mode etc.)
  }
}

export function loadBudget(): number {
  try {
    const raw = localStorage.getItem(BUDGET_KEY);
    const value = Number(raw);
    return Number.isFinite(value) && value > 0 ? value : 0;
  } catch {
    return 0;
  }
}

export function saveBudget(budget: number): void {
  try {
    localStorage.setItem(BUDGET_KEY, String(budget));
  } catch {
    // ignore storage errors
  }
}
